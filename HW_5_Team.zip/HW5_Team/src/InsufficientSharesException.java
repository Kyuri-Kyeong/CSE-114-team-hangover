@SuppressWarnings("serial")
public class InsufficientSharesException extends Exception {
	public InsufficientSharesException(String s) {
		super(s);
	}
}
