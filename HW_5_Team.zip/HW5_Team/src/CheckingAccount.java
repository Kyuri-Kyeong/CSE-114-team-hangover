//
// name: Kyuri Kyeong
// Stonybrook ID: 111827215
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//

public class CheckingAccount extends GeneralAccount implements Savings {
	
	public CheckingAccount(int accountNumber, String firstName, String lastName, double initialBalance){
		super(accountNumber, firstName, lastName, "70", initialBalance);
	}

	public int getAccountNumber() {
		return super.getNumber();
	}
	
	private void checkCashed(double amount) throws InsufficientFundsException {
		super.withdrawal(amount);
	}

	private void pointOfSale(double amount) throws InsufficientFundsException {
		super.withdrawal(amount);
	}

	public double getBalance() {
		return balance;
	}

	@SuppressWarnings("finally")
	public boolean addTransaction(Transaction trans) {
	try {
		if (trans instanceof SavingsTransaction && ((SavingsTransaction) trans).selfCheck()) {
			double amount = ((SavingsTransaction) trans).getAmount();
			switch (trans.getTransactionType()) { 
			case Deposit: {this.deposit(amount);break;}
			case Withdrawal: {this.withdrawal(amount);break;}
			case Interest: {this.interest(amount);break;}
			case CheckCashed: {this.checkCashed(amount);break;}
			case PointOfSale: {this.pointOfSale(amount);break;}
			default : {return false;}
			}
		} else {return false;}
		return super.addTransaction(trans);
		}
	finally{
		return false;
	}
	}

	public String toString() {
		return super.toString() + "-" + this.getSuffix() + " $ " + String.format("%.2f", this.getBalance());
	}
}