//
// name: Kyuri Kyeong
// Stonybrook ID: 111827215
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//

public abstract class GeneralAccount extends Account implements Savings{
	double balance;
	
	public GeneralAccount(int accountNumber, String firstName, String lastName, String suffix, double balance){
			super(accountNumber, firstName, lastName, suffix);
			if (balance < 0 ) {
				System.out.println("Negative balance not allowed");
				balance = 0;
			}
			else {
				this.balance = balance;
			}
	}
	
	void deposit(double amount) {
		balance += amount;
	}
	
	//verify withdrawal
	void withdrawal(double amount) throws InsufficientFundsException  {
		if (amount > balance) {
			throw new InsufficientFundsException("Withdrawal too large");
		}
		
		balance -= amount;
	}
	
	void interest(double interest) {
		balance = balance * (1+ interest);
	}
	
	public double getBalance() {
		return balance;
	}
}
