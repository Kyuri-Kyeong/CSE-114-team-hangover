//
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//



public class StockExchange {

	static String[] symbols = {"IBM", "APPL", "RCI", "INTL", "MOT", "HP",
			 "LCKH", "BOE", "DELL", "ORCL"};
	static double[] costs = {105.5, 115.4, 98.70, 85.50, 25.30, 10, 55.70, 76.50, 101.10, 35.50};

	public static double getPriceBySymbol(String symbol) {
		double returnValue = -1.0;
		for (int i = 0; i < symbols.length; i++) {
			if (symbols[i].equals(symbol)) {
				returnValue = costs[i];
				break;
			}
		}
		return returnValue;
	}
	public static int indexof(String symbol) {
		int i = symbols.length - 2;
		for (i++; i > -1; i--) {
			if (symbol.equals(symbols[i])) {
				break;
			}
		}
		return i;
	}
}