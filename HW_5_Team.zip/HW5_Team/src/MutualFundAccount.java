//
// name: Kyuri Kyeong
// Stonybrook ID: 111827215
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//

public class MutualFundAccount extends Account implements Investment {
	double numberOfShares;
	double pricePerShare;
	
	public MutualFundAccount(String firstName, String lastName, int accountNumber, double numberOfShares, double pricePerShare) {
		super (accountNumber, firstName, lastName, "MF");
		this.numberOfShares = numberOfShares;
		this.pricePerShare = pricePerShare;
	}
	
	public double getValue() {
		return numberOfShares * pricePerShare;
	}
	
	public boolean addTransaction(Transaction trans) {
		if (trans instanceof MutualFundTransaction && ((MutualFundTransaction) trans).selfCheck()) {
			double amount = ((MutualFundTransaction) trans).getAmount();
			switch (trans.getTransactionType()) { 
			case buyMF: {numberOfShares += amount;break;}
			case sellMF: {numberOfShares -=amount;break;}
			case updateMFSharePrice: {pricePerShare = amount;break;}
			default : {return false;}
			}
		} else {return false;}
		return super.addTransaction(trans);
	}
	
	public String toString() {
		return super.toString() + "-" + this.getSuffix() + " $ " + String.format("%.2f", this.getValue());
	}
}

