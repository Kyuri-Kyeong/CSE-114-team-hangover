public class CheckingAccount extends GeneralAccount implements Savings {

	public CheckingAccount(int accountNumber, String firstName, String lastName, double initialBalance) {
		super(accountNumber, firstName, lastName, "70", initialBalance);
	}

	public int getAccountNumber() {
		return super.getNumber();
	}

	public void checkCashed(double amount) {
		super.withdrawal(amount);
	}

	public void pointOfSale(double amount) {
		super.withdrawal(amount);
	}

	public double getBalance() {
		return balance;
	}

	public boolean addTransaction(Transaction trans) {

		if (trans instanceof SavingsTransaction && ((SavingsTransaction) trans).getAmount() >= 0) {
			switch (trans.getTransactionType()) {
			case Deposit:
				this.deposit(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			case Withdrawal:
				this.withdrawal(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			case Interest:
				this.interest(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			case CheckCashed:
				this.checkCashed(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			case PointOfSale:
				this.pointOfSale(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			default:
				return false;
			}
		}
		return false;
	}

	public String toString() {
		return this.getNumber() + "-" + this.getSuffix() + " " + this.getBalance();
	}
}