public class CheckingAccount extends GeneralAccount implements Savings {
	
	public CheckingAccount(int accountNumber, String firstName, String lastName, double initialBalance){
		super(accountNumber, firstName, lastName, "70", initialBalance);
	}

	public int getAccountNumber() {
		return super.getNumber();
	}
	
	private void checkCashed(double amount) throws InsufficientFundsException {
		super.withdrawal(amount);
	}

	private void pointOfSale(double amount) throws InsufficientFundsException {
		super.withdrawal(amount);
	}

	public double getBalance() {
		return balance;
	}

	@SuppressWarnings("finally")
	public boolean addTransaction(Transaction trans) {
	try {
		if (trans instanceof SavingsTransaction && ((SavingsTransaction) trans).getAmount() >= 0) {
			switch (trans.getTransactionType()) {
			case Deposit:
				this.deposit(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			case Withdrawal:
				this.withdrawal(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			case Interest:
				this.interest(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			case CheckCashed:
				this.checkCashed(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			case PointOfSale:
				this.pointOfSale(((SavingsTransaction) trans).getAmount());
				return super.addTransaction(trans);
			default:
				return false;
			}
		}
		return false;
	}
	finally{
		return false;
	}
	}

	public String toString() {
		return this.getNumber() + "-" + this.getSuffix() + " " + String.format("%.2f", this.getBalance());
	}
}