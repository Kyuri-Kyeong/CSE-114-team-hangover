import java.util.Arrays;

public class StockAccount extends Account {
	
	private StockHolding[] stockHoldings = new StockHolding[100];
	private int numOfStockHoldings = 0;
	
	public StockAccount(String firstName, String lastName, int accountNumber) {
		super(accountNumber,firstName,lastName,"SA");
	}
	
	private void buyStock(String symbol, int numOfShares,Savings savAcc,Transaction trans) throws Exception {
		double priceOfStock = 0;
		int i = 0;
		
		//verify if symbol exists
		if (StockExchange.indexof(symbol) != -1) {
			//calculate price of stock
			priceOfStock = numOfShares * StockExchange.getPriceBySymbol(symbol);
			//take funds from account
			Transaction transaction = new SavingsTransaction(trans.date,trans.accountNumber ,TransactionType.Withdrawal,priceOfStock);
			savAcc.addTransaction(transaction);
			//look for symbol in stockholdings
			for ( i = 0; (i < numOfStockHoldings) && (stockHoldings[i].getSymbol() != symbol); i++ );
			//update stockholding
			if (i != numOfStockHoldings ) {
				stockHoldings[i].addShares(numOfShares);
			}
			//or add
			else {
			stockHoldings[numOfStockHoldings] = new StockHolding(symbol);
			stockHoldings[numOfStockHoldings].addShares(numOfShares);
			numOfStockHoldings++;
			}
		}	
		else {
			throw new InvalidSymbolException("Symbol does not exist");
		}
	}
	
	private void sellStock(String symbol, int numOfShares, Savings acc,Transaction trans) throws InsufficientFundsException, NegativeCurrencyException, InvalidSymbolException, InsufficientSharesException {
		double priceOfStock = 0;
		int i = 0;
		
		//verify if symbol exists
		if (StockExchange.indexof(symbol) != -1) {
			//calculate price of stock
			priceOfStock = numOfShares * StockExchange.getPriceBySymbol(symbol);
			//look for symbol in stockholdings
			for ( i = 0; (stockHoldings[i].getSymbol() != symbol) && (i < numOfStockHoldings); i++ );
			//if found, deduct shares and deposit funds in General account
			if (i != numOfStockHoldings ) {
				//if the amount of shares is sufficient, deduct and deposit
				if (stockHoldings[i].deductShare(numOfShares)) {;
					//deposit funds in account
					Transaction transaction = new SavingsTransaction(trans.date,trans.accountNumber ,TransactionType.Deposit,priceOfStock);
					acc.addTransaction(transaction);
				}
				else {
					throw new InsufficientSharesException("Insufficient shares in stockholding to carry out transaction");
				}
			}
			else {
				throw new InsufficientSharesException("Stock holding for symbol does not exist");
			}
		}
		else {
			throw new InvalidSymbolException("Symbol does not exist");
		}
	}
	
	public double getValue() {
		double total = 0;
		//for each stockholding
		for(int i = 0;i < numOfStockHoldings ;i++) {
			//compute stock value
			//add to total
			total += stockHoldings[i].getShares() * StockExchange.getPriceBySymbol(stockHoldings[i].getSymbol());
		}
		//display total
		return total;
	}
	
	public StockHolding[] getHoldings() {
		return Arrays.copyOf(stockHoldings,numOfStockHoldings);
	}
	
	public String toString() {
		return this.getAccountNumber() + "-" + this.getSuffix() + " " + this.getValue();
	}
	
	@SuppressWarnings("finally")
	public boolean addTransaction(Transaction trans) {
	try {
		if (trans instanceof StockInvestmentTransaction) {
			//initialise variables
			String symbol = ((StockInvestmentTransaction) trans).getStockHolding().getSymbol();
			int numOfShares = ((StockInvestmentTransaction) trans).getStockHolding().getShares();
			Savings acc = ((StockInvestmentTransaction) trans).getAccount();
			
			//buyStock
			if (trans.getTransactionType() == TransactionType.buyStock ) {
				this.buyStock(symbol, numOfShares,acc, trans);
				return super.addTransaction(trans);
			}
			
			//sellStock
			if (trans.getTransactionType() == TransactionType.sellStock ) {
				this.sellStock(symbol, numOfShares,acc, trans);
				return super.addTransaction(trans);
			}
			
			//else invalid
			return false;
		}
		
		//else invalid
		return false;
	}
	finally {
		return false;
	}
	}
	
}
