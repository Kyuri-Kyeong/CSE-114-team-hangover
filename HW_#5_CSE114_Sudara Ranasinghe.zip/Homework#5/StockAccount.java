
public class StockAccount extends Account {
	
	private StockHolding[] stockHoldings = new StockHolding[100];
	private int numOfStockHoldings = 0;
	
	public StockAccount(String firstName, String lastName, int accountNumber) {
		super(accountNumber,firstName,lastName,"SA");
	}
	
	private void buyStock(String symbol, int numOfShares,Savings savAcc,Transaction trans) {
		double priceOfStock = 0;
		int i = 0;
		//calculate price of stock
		priceOfStock = numOfShares * StockExchange.getPriceBySymbol(symbol);
		//take funds from account
		Transaction transaction = new SavingsTransaction(trans.date,trans.accountNumber ,TransactionType.Withdrawal,priceOfStock);
		savAcc.addTransaction(transaction);
		//add stock to stock holdings
			//look for symbol in stockholdings
		for ( i = 0; (stockHoldings[i].getSymbol() != symbol) && (i < numOfStockHoldings); i++ );
			//update stockholding
		if (i != numOfStockHoldings ) {
			stockHoldings[i].addShares(numOfShares);
		}
		else {
			//or create new stockholding for new symbol
		stockHoldings[numOfStockHoldings] = new StockHolding(symbol);
		stockHoldings[numOfStockHoldings].addShares(numOfShares);
		numOfStockHoldings++;
		}
	}
	
	private void sellStock(String symbol, int numOfShares, Savings acc,Transaction trans) {
		double priceOfStock = 0;
		int i = 0;
		//calculate price of stock
		priceOfStock = numOfShares * StockExchange.getPriceBySymbol(symbol);
		//remove stock from stockholdings
			//look for symbol in stockholdings
				for ( i = 0; (stockHoldings[i].getSymbol() != symbol) && (i < numOfStockHoldings); i++ );
			//update stockholding
				if (i != numOfStockHoldings ) {
					stockHoldings[i].deductShare(numOfShares);
				}
		//deposit funds in account
				Transaction transaction = new SavingsTransaction(trans.date,trans.accountNumber ,TransactionType.Deposit,priceOfStock);
				acc.addTransaction(transaction);
	}
	
	public double getValue() {
		double total = 0;
		//for each stockholding
		for(int i = 0;i < numOfStockHoldings ;i++) {
			//compute stock value
			//add to total
			total += stockHoldings[i].getShares() * StockExchange.getPriceBySymbol(stockHoldings[i].getSymbol());
		}
		//display total
		return total;
	}
	
	public StockHolding[] getHoldings() {
		return stockHoldings;
	}
	
	public String toString() {
		return this.getAccountNumber() + "-" + this.getSuffix() + " " + this.getValue();
	}
	
	public boolean addTransaction(Transaction trans) {
		if (trans instanceof StockInvestmentTransaction) {
			//initialise variables
			String symbol = ((StockInvestmentTransaction) trans).getStockHolding().getSymbol();
			int numOfShares = ((StockInvestmentTransaction) trans).getStockHolding().getShares();
			Savings acc = ((StockInvestmentTransaction) trans).getAccount();
			
			//buyStock
			if (trans.getTransactionType() == TransactionType.buyStock ) {
				this.buyStock(symbol, numOfShares,acc, trans);
				return super.addTransaction(trans);
			}
			
			//sellStock
			if (trans.getTransactionType() == TransactionType.sellStock ) {
				this.sellStock(symbol, numOfShares,acc, trans);
				return super.addTransaction(trans);
			}
			
			//else invalid
			return false;
		}
		
		//else invalid
		return false;
	}
	
}
