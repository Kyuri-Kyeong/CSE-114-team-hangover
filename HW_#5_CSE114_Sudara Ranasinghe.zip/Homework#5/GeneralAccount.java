public abstract class GeneralAccount extends Account implements Savings{
	double balance;
	
	public GeneralAccount(int accountNumber, String firstName, String lastName, String suffix, double balance) {
		super(accountNumber, firstName, lastName, suffix);
		this.balance = balance;
	}
	void deposit(double amount) {
		balance += amount;
	}
	void withdrawal(double amount) {
		balance -= amount;
	}
	void interest(double interest) {
		balance = balance * (1+ interest);
	}
	public double getBalance() {
		return balance;
	}
}
