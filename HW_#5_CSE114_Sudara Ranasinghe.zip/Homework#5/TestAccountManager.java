//
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//



import java.text.SimpleDateFormat;
import java.util.Date;

public class TestAccountManager {
	public static void main(String[] args) {
		
		SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd");
		Date today = new Date();
		String todayDate = ft.format(today);
		Transaction t1 = new SavingsTransaction(todayDate, 12345, TransactionType.Deposit, 1000.00);
		Transaction t2 = new SavingsTransaction(todayDate, 12345, TransactionType.PointOfSale, 15.53);
		Transaction t3 = new SavingsTransaction(todayDate, 12345, TransactionType.CheckCashed, 40.00);
		Transaction t4 = new SavingsTransaction(todayDate, 12345, TransactionType.Deposit, 2100.00);
		Transaction t5 = new SavingsTransaction(todayDate, 12345, TransactionType.PointOfSale, 10.05);
		Transaction t6 = new SavingsTransaction(todayDate, 12345, TransactionType.Interest, 0.37);
		CheckingAccount ca = new CheckingAccount(12345, "Joseph", "Cool", 250.00);
		ca.addTransaction(t1);
		ca.addTransaction(t2);
		ca.addTransaction(t3);
		ca.addTransaction(t4);
		ca.addTransaction(t5);
		ca.addTransaction(t6);
		


		Transaction[] listOfTrans = ca.getTransactions();
		for (int i = 0; i < listOfTrans.length; i++) {
			System.out.print("Trans: " + i + " : Type = " + String.format("%-12s", listOfTrans[i].tt2String(listOfTrans[i].getTransactionType())));
			System.out.print(" : Amount = ");
			System.out.printf("$%10.2f",  ((SavingsTransaction) listOfTrans[i]).amount);
			System.out.println();

		}
		System.out.println("\n");
		System.out.println(ca);
		System.out.println();

		Transaction t01 = new SavingsTransaction(todayDate, 12345, TransactionType.Deposit, 6100.00);
		Transaction t02 = new SavingsTransaction(todayDate, 12345, TransactionType.Withdrawal, 50.00);
		Transaction t03 = new SavingsTransaction(todayDate, 12345, TransactionType.CheckCashed, 150.00);
		Transaction t04 = new SavingsTransaction(todayDate, 12345, TransactionType.Deposit, 4250.50);
		Transaction t05 = new SavingsTransaction(todayDate, 12345, TransactionType.Withdrawal, 120.00);
		Transaction t06 = new SavingsTransaction(todayDate, 12345, TransactionType.Interest, 1.43);
		Transaction t07 = new SavingsTransaction(todayDate, 12345, TransactionType.Withdrawal, 15);
		Transaction t08 = new SavingsTransaction(todayDate, 12345, TransactionType.Withdrawal, 400.00);
		SavingsAccount sa = new SavingsAccount(12345, "Joseph", "Cool", 250.00);
		sa.addTransaction(t01);
		sa.addTransaction(t02);
		sa.addTransaction(t03);
		sa.addTransaction(t04);
		sa.addTransaction(t05);
		sa.addTransaction(t06);
		sa.addTransaction(t07);
		sa.addTransaction(t08);

		System.out.println(sa);
		System.out.println();
		
		Transaction t11 = new SavingsTransaction(todayDate, 12346, TransactionType.Deposit, 4100.00);
		Transaction t12 = new SavingsTransaction(todayDate, 12346, TransactionType.PointOfSale, 155.57);
		Transaction t13 = new SavingsTransaction(todayDate, 12346, TransactionType.CheckCashed, 50.00);
		Transaction t14 = new SavingsTransaction(todayDate, 12346, TransactionType.Deposit, 4250.50);
		Transaction t15 = new SavingsTransaction(todayDate, 12346, TransactionType.PointOfSale, 110.15);
		Transaction t16 = new SavingsTransaction(todayDate, 12346, TransactionType.Interest, 1.43);
		CheckingAccount ca2 = new CheckingAccount(12346, "Jane", "Doe", 1250.00);
		ca2.addTransaction(t11);
		ca2.addTransaction(t12);
		ca2.addTransaction(t13);
		ca2.addTransaction(t14);
		ca2.addTransaction(t15);
		ca2.addTransaction(t16);
		listOfTrans = ca2.getTransactions();
		for (int i = 0; i < listOfTrans.length; i++) {
			System.out.print("Trans: " + i + " : Type = " + String.format("%-12s", listOfTrans[i].tt2String(listOfTrans[i].getTransactionType())));
			System.out.print(" : Amount = ");
			System.out.printf("$%10.2f",  ((SavingsTransaction) listOfTrans[i]).amount);
			System.out.println();
		}
		System.out.println("\n");
		System.out.println(ca2);

		Transaction t21 = new StockInvestmentTransaction(todayDate, 12346, TransactionType.buyStock, new StockHolding("INTL", 5), ca2);
		Transaction t22 = new StockInvestmentTransaction(todayDate, 12346, TransactionType.buyStock, new StockHolding("HP", 25), ca2);
		Transaction t23 = new StockInvestmentTransaction(todayDate, 12346, TransactionType.buyStock, new StockHolding("APPL", 2), ca2);
		Transaction t24 = new StockInvestmentTransaction(todayDate, 12346, TransactionType.sellStock, new StockHolding("APPL", 25), ca2);
		Transaction t25 = new StockInvestmentTransaction(todayDate, 12346, TransactionType.sellStock, new StockHolding("INTL", 2), ca2);
		Transaction t26 = new StockInvestmentTransaction(todayDate, 12346, TransactionType.buyStock, new StockHolding("APPL", 500), ca2);
		StockAccount sa2 = new StockAccount("Jane", "Doe", 12346);
		sa2.addTransaction((StockInvestmentTransaction)t21);
		sa2.addTransaction((StockInvestmentTransaction)t22);
		sa2.addTransaction((StockInvestmentTransaction)t23);
		sa2.addTransaction((StockInvestmentTransaction)t24);
		sa2.addTransaction((StockInvestmentTransaction)t25);
		sa2.addTransaction((StockInvestmentTransaction)t26);
		System.out.println(sa2);
		
		
		Transaction t31 = new MutualFundTransaction(todayDate, 12345, TransactionType.buyMF, 200.00, ca);
		Transaction t32 = new MutualFundTransaction(todayDate, 12345, TransactionType.buyMF, 300.00, ca);
		Transaction t33 = new MutualFundTransaction(todayDate, 12345, TransactionType.sellMF, 10, ca);
		Transaction t34 = new MutualFundTransaction(todayDate, 12345, TransactionType.sellMF, 15, ca);
		MutualFundAccount mfa1 = new MutualFundAccount("Joseph", "Cool", 12345, 200.0, 35.00);
		mfa1.addTransacton((MutualFundTransaction)t31);
		mfa1.addTransacton((MutualFundTransaction)t32);
		mfa1.addTransacton((MutualFundTransaction)t33);
		mfa1.addTransacton((MutualFundTransaction)t34);

		System.out.println(mfa1);
		Transaction[] mfaTransactions = mfa1.getTransactions();
		if (mfaTransactions != null) {
			for (int i = 0; i < mfaTransactions.length; i++) {
				MutualFundTransaction mfaTrans = (MutualFundTransaction) mfaTransactions[i];
				System.out.println("Transaction: " + i + " : Type = " + String.format("%-6s", mfaTrans.tt2String(mfaTrans.getTransactionType()).trim()) + " Amount = " + String.format("%8.2f", mfaTrans.getAmount()));
			}
		}
		System.out.println();
		System.out.println(ca);
		System.out.println(ca2);
		System.out.println(sa);
		
		System.out.println("mfa1: Value = $" + String.format("%8.2f", mfa1.getValue()));
		System.out.println("sa2:  Value = $" + String.format("%8.2f", sa2.getValue()));

	}
}
