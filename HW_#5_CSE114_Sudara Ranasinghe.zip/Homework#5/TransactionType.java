//
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//



public enum TransactionType {
	Deposit,
	CheckCashed,
	Interest,
	PointOfSale,
	Withdrawal,
	buyMF,
	buyStock,
	sellMF,
	sellStock,
	updateMFSharePrice
	
}