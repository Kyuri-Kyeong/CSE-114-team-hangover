@SuppressWarnings("serial")
public class InvalidSymbolException extends Exception  {
	public InvalidSymbolException(String s) {
		super(s);
	}
}
