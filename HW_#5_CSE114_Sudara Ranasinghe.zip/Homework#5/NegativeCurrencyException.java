@SuppressWarnings("serial")
public class NegativeCurrencyException extends Exception {
	public NegativeCurrencyException(String s){
		super(s);
	}
}
