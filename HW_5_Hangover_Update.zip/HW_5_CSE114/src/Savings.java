//
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//



public interface Savings {
	public double getBalance();
	
	public int getAccountNumber();
	
	public boolean addTransaction(Transaction trans);
}