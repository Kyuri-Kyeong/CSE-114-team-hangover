//
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//




//This class stores information on a stock found within the user's portfolio
public class StockHolding {
	private String symbol;
	private int shares;

	/* Constructs a StockHolding in the case no pre-existing number of shares
	 * is passed as an argument.
	 */
	StockHolding(String symbol) {
		this.symbol = symbol;
		shares = 0;
	}
	/* Constructs a StockHolding in the case a pre-existing number of shares
	 * is passed as an argument.
	 */
	StockHolding(String symbol, int numberOfShares) {
		this.symbol = symbol;
		shares = numberOfShares;

	}
	/* This increases the number of shares of this stock currently said to
	 * be owned by a specified value.
	 */
	public void addShares(int numberToAdd) {
		shares += numberToAdd;
	}
	/* This decreases the number of shares of this stock currently said to
	 * be owned by a specified value.
	 */
	public boolean deductShare(int numberToDeduct) {
		if(shares - numberToDeduct >= 0)
		{
			shares -= numberToDeduct;
			return true;
		}
		else
		{
			System.out.println("Not enough shares");
			return false;
		}
	}
	public String getSymbol() { return symbol; }
	public int getShares() { return shares; }
}