//
// Bank Account Manager
// CSE114 - Spring2018
// HW 5
//



public interface Investment {
	public double getValue();
	
	
	public boolean addTransaction(Transaction trans);
	
}